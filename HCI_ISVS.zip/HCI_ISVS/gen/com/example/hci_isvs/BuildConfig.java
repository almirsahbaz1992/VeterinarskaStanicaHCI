/** Automatically generated file. DO NOT MODIFY */
package com.example.hci_isvs;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}